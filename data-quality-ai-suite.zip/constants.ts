export const APPLICATIONS: string[] = ['CRM', 'ERP', 'Billing System', 'Data Warehouse', 'Marketing Automation'];
export const OPERATIONS: string[] = ['Business_Rules', 'Technical_Rules', 'Estimations', 'Schema'];
export const DOMAINS: string[] = ['Banking', 'Healthcare', 'Retail', 'Telecommunications', 'Insurance'];
export const DEPARTMENTS: string[] = ['Customer Relationship', 'Finance', 'Marketing', 'Human Resources', 'Operations'];